package databaselayer

type InfluxdbHandler struct {
}

func NewInfluxdbHandler() *InfluxdbHandler {
	return nil
}
