package databaselayer

type MySQLHandler struct {
}

func NewMySQLHandler() *MySQLHandler {
	return nil
}

func (handler *MySQLHandler) GetAvailableDynos() {

}
