package databaselayer

type SQLiteHandler struct {
}

func NewSQLiteHandler() *SQLiteHandler {
	return nil
}

func (handler *SQLiteHandler) GetAvailableDynos() {

}
