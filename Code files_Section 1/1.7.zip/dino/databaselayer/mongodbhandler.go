package databaselayer

type MongodbHandler struct {
}

func NewMongodbHandler() *MongodbHandler {
	return nil
}

func (handler *MongodbHandler) GetAvailableDynos() {

}
